#!/bin/bash
#export PYTHONPATH=$PYTHONPATH:/modules

# training
cd train_code
python modelTrain.py 

cd ..
# Testing
cd predict_code
python modelEvaluation.py
