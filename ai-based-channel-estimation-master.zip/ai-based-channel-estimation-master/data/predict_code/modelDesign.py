# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 14:29:40 2021

@author: 5106
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Jul 10 17:27:27 2021

@author: 5106
"""

import numpy as np
import torch
import torch.nn as NN
import torch.nn.functional as F

#class conv_block(NN.Module):
#    """
#    Convolution Block 
#    """
#    def __init__(self, in_ch, out_ch):
#        super(conv_block, self).__init__()
#        
#        self.conv = NN.Sequential(
#            NN.Conv2d(in_ch, out_ch, kernel_size=3, stride=2, padding=1, bias=True),
#            NN.BatchNorm2d(out_ch),
#            NN.LeakyReLU(negative_slope=0.3),
#            NN.Conv2d(out_ch, out_ch, kernel_size=3, stride=1, padding=1, bias=True),
#            NN.BatchNorm2d(out_ch),
#            NN.LeakyReLU(negative_slope=0.3))
#
#    def forward(self, x):
#
#        x = self.conv(x)
#        return x
#    
class conv_block1(NN.Module):
    """
    Convolution Block 
    """
    def __init__(self, in_ch, out_ch, pads, dilas):
        super(conv_block1, self).__init__()
        
        self.conv = NN.Sequential(
            NN.Conv2d(in_ch, out_ch, kernel_size=3, stride=1, padding=pads, dilation=dilas,bias=True),
#            NN.BatchNorm2d(out_ch),
            # NN.InstanceNorm2d(out_ch),
#            NN.LeakyReLU(negative_slope=0.3))
            NN.PReLU())

    def forward(self, x):

        x = self.conv(x)
        return x
#
#
class up_conv(NN.Module):
    """
    Up Convolution Block
    """
    def __init__(self, in_ch, out_ch):
        super(up_conv, self).__init__()
        self.up = NN.Sequential(
#            NN.ConvTranspose2d(in_ch , out_ch, kernel_size=3, stride=2, padding=1,bias=True),
            NN.Upsample(scale_factor=2,mode='nearest'),
            NN.Conv2d(in_ch, out_ch, kernel_size=3, stride=1, padding=1, bias=True),
            # NN.InstanceNorm2d(out_ch),
#            NN.BatchNorm2d(out_ch),
#            NN.LeakyReLU(negative_slope=0.3)
            NN.PReLU()
        )

    def forward(self, x):
        x = self.up(x)
        return x

class _Res_Block(NN.Module):
    def __init__(self, in_ch, out_ch):
        super(_Res_Block, self).__init__()

        self.res_conv = NN.Conv2d(in_ch, out_ch, kernel_size=3, padding=1)
        self.res_conb = NN.Conv2d(out_ch, out_ch, kernel_size=3, padding=1)
        self.relu = NN.PReLU()
        self.instan = NN.InstanceNorm2d(out_ch)

    def forward(self, x,al=1):

        y = self.relu(self.res_conv(x))
        y = self.res_conb(y)
        # y = self.res_conv(self.relu(x))
        # y = self.res_conb(self.relu(y))
        # y = self.res_conv(self.relu(self.instan(x)))
        # y = self.res_conb(self.relu(self.instan(y)))
        y *= al
        y = torch.add(y, x)
        return y
    
#class _Res_Blocka(NN.Module):
#    def __init__(self, in_ch, out_ch, b_ch):
#        super(_Res_Blocka, self).__init__()
#
#        self.res_conv = NN.Conv2d(in_ch, b_ch, kernel_size=3, padding=1)
#        self.res_conb = NN.Conv2d(b_ch, out_ch, kernel_size=3, padding=1)
#        self.relu = NN.LeakyReLU(negative_slope=0.3)
#
#    def forward(self, x):
#
#        y = self.relu(self.res_conv(x))
#        y = self.res_conb(y) 
#        y *= 1
#        y = torch.add(y, x)
#        return y
#    
class _Res_Blockb(NN.Module):
    def __init__(self, in_ch, out_ch, b_ch, l_ch):
        super(_Res_Blockb, self).__init__()

        self.res_conv = NN.Conv2d(in_ch, b_ch, kernel_size=1, padding=0)
        self.res_conb = NN.Conv2d(b_ch, l_ch, kernel_size=1, padding=0)
        self.res_conl = NN.Conv2d(l_ch, out_ch, kernel_size=3, padding=1)
        self.relu = NN.PReLU()

    def forward(self, x):

        y = self.relu(self.res_conv(x))
        y = self.res_conb(y)
        y = self.res_conl(y)
        y *= 1
        y = torch.add(y, x)
        return y

class AIModel(NN.Module):
    def __init__(self, ):
        super(AIModel, self).__init__()
#        for i in range(7):
#            in_channels = 2 if i == 0 else 32
#            out_channels = 2 if i == 6 else 32
#            # 和tensorflow、keras不同，torch.nn.Conv2d不支持指定'same'或'valid'的padding方式
#            # 所以根据不同的kernel_size和padding大小，可能会造成输出维度不等于输入。
#            # 想要实现same padding，可以用 F.pad() 手动进行padding，可实现上下左右不等长的填充。
#            conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
#            torch.nn.init.normal_(conv.weight, 0, 0.05)
#            torch.nn.init.constant_(conv.bias, 0)
#            setattr(self, 'layer_%d' % (i + 1), conv)
        
#        in_channels = 2
        out_channels = 192
        out_ch = 32
        b_channels = 192
        l_channels = 25
        self.resconvbb = _Res_Blockb(out_ch, out_ch,b_channels,l_channels)
        
        self.resconv = _Res_Block(out_channels, out_channels)
#        self.convb = NN.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
#        self.convc = NN.Conv2d(out_channels*2, out_channels, kernel_size=3, padding=1)
#        self.conv0 = NN.Conv2d(out_channels, in_channels, kernel_size=3, padding=1)
#        self.conv1 = NN.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
#        self.convd = NN.Conv2d(in_channels*2, in_channels, kernel_size=1, padding=0)
        n1 = 48
        self.resconvb = _Res_Block(n1, n1)
        filters = [n1, n1 * 2, n1 * 4, n1 * 8, n1 * 16]
        in_ch=2
        out_ch=2
        
        self.Maxpool1 = NN.MaxPool2d(kernel_size=2, stride=2)
        self.Maxpool2 = NN.MaxPool2d(kernel_size=2, stride=2)
#        self.Maxpool3 = NN.MaxPool2d(kernel_size=2, stride=2)
#        self.Maxpool4 = NN.MaxPool2d(kernel_size=2, stride=2)
        
        self.ConvII = conv_block1(filters[0]+2, filters[0],1,1)
#        self.ConvI = _Res_Block(in_ch, filters[0])
        self.Conv1 = _Res_Block(filters[0], filters[0])
        self.Conv2 = _Res_Block(filters[1], filters[1])
        self.Conv3 = _Res_Block(filters[2], filters[2])
#        self.Conv4 = _Res_Block(filters[3], filters[3])
#        self.Conv4 = conv_block1(filters[2], filters[3])
#        self.Conv5 = conv_block(filters[4], filters[4])
        
        self.Conv11 = conv_block1(in_ch, filters[0],1,1)
        self.Conv22 = conv_block1(filters[0], filters[1],1,1)
        self.Conv33 = conv_block1(filters[1], filters[2],1,1)
#        self.Conv44 = conv_block1(filters[2], filters[3])
#        self.Conv4 = conv_block1(filters[2], filters[3])
#        self.Conv55 = conv_block1(filters[3], filters[4])
        

#        self.Up5 = up_conv(filters[4], filters[3])
#        self.Up55 = conv_block1(filters[4], filters[3])
#        self.Up_conv5 = _Res_Block(filters[3], filters[3])

#        self.Up4 = up_conv(filters[3], filters[2])
#        self.Up44 = conv_block1(filters[3], filters[2])
#        self.Up_conv4 = _Res_Block(filters[2], filters[2])

        self.Up3 = up_conv(filters[2], filters[1])
        self.Up33 = conv_block1(filters[2], filters[1],1,1)
        self.Up_conv3 = _Res_Block(filters[1], filters[1])

        self.Up2 = up_conv(filters[1], filters[0])
        self.Up_conv2 = _Res_Block(filters[0], filters[0])
        self.Up22 = conv_block1(filters[1], filters[0],1,1)
        self.Conv = NN.Conv2d(filters[0], out_ch, kernel_size=1, stride=1, padding=0)
        
        self.active = torch.nn.Tanh()


    def forward(self, x, snr, data_format='channels_last'):
        # torch.nn.Conv2d默认输入是 [B,C,H,W] 的格式
        if data_format not in {'channels_first', 'channels_last'}:
            raise ValueError('The `data_format` argument must be one of '
                             '"channels_first", "channels_last". Received: ' +
                             str(data_format))
        if data_format == 'channels_last':
            x = x.permute(0, 3, 1, 2)   # out shape [B, C, H, W]
        _, _, H, W = x.shape
        
#        out = self.convb(x) # 48 x 2
#        
#        for i in range(3):
#            out = self.resconv(out)
#            
#       
        size = (2, 7)
        up_size = (H * size[0], W * size[1])
#        out = NN.UpsamplingNearest2d(size=up_size)(x) #2 x 96 x 14
#        out = self.Conv11(x)
#        for i in range(3):
#            out = self.resconvbb(out)
        
#        out =  NN.UpsamplingNearest2d(size=up_size)(x) #2 x 96 x 14
        out1 = NN.Upsample(size=up_size,mode='nearest')(x)
#        out1 = out
#        out = self.Conv11(out)
#        for i in range(3):
#            out = self.resconvbb(out)
#        out2 = torch.cat((out1, out), dim=1)
#        else:
#            out = self.Conv11(out1)
        
#        e1 = self.ConvII(out2) # 16 x 96 x 14
        e1 = self.Conv11(out1) # 16 x 96 x 14
        e1 = self.Conv1(e1)
#        e1 = self.Conv22(e1)
        
        e2 = self.Maxpool1(e1)
        e2 = self.Conv22(e2)
        for i in range(2):
            e2 = self.Conv2(e2) # 128 x 48 x 7
        
        e3 = self.Maxpool2(e2)
        e3 = self.Conv33(e3) # 256 x 24 x 4
        for i in range(3):
            e3 = self.Conv3(e3) # 256 x 24 x 4
        
        e31 = e3
        for i in range(3):
            e3 = self.resconv(e3,al = 1)
        e3 = torch.add(e31,e3)

#        e4 = self.Maxpool3(e3)
#        e4 = self.Conv44(e4) # 256 x 24 x 4
#        e4 = self.Conv4(e4) # 512 x 12 x 2
        

#        e4 = self.Maxpool3(e3)
#        e4 = self.Conv4(e3) # 512 x 12 x 2
#
#        e5 = self.Maxpool4(e4)
#        e5 = self.Conv5(e5)

#        d5 = self.Up5(e5)
#        d5 = torch.cat((e4, d5), dim=1)
#
#        d5 = self.Up_conv5(d5)

#        d4 = self.Up4(e4) # 256 x 23 x 3
#        d4 = F.pad(d4, pad=(0,1,0,0,0,0), mode="constant",value=0) # 256 x 24 x 4
#        d4 = torch.cat((e3, d4), dim=1) # 512 x 24 x 4
#        d4 = self.Up_conv4(d4) # 256 x 24 x 4

        d3 = self.Up3(e3) 
        d3 = F.pad(d3, pad=(0,1,0,0,0,0), mode="constant",value=0) # 128 x 48 x 7
        d3 = torch.cat((e2, d3), dim=1)
        d3 = self.Up33(d3)
        for i in range(3):
            d3 = self.Up_conv3(d3)

        d2 = self.Up2(d3) 
#        d2 = F.pad(d2, pad=(0,1,1,0,0,0), mode="constant",value=0) # 64 x 96 x 14
        d2 = torch.cat((e1, d2), dim=1)
        d2 = self.Up22(d2)
        for i in range(2):
            d2 = self.Up_conv2(d2) 

        out = self.Conv(d2)
        out = torch.add(out,out1)
        

#        for i in range(2):
#            conv = getattr(self, 'layer_%d' % (i + 1))
#            out = conv(out)
#            out = F.leaky_relu(out, negative_slope=0.3)
        

        if data_format == 'channels_last':
            out = out.permute(0, 2, 3, 1)
#            out1 = out1.permute(0, 2, 3, 1)
#            out2 = out2.permute(0, 2, 3, 1)
            
        return out



def NMSE(x, x_hat):
    x_real = np.reshape(x[:, :, :, 0], (len(x), -1))
    x_imag = np.reshape(x[:, :, :, 1], (len(x), -1))
    x_hat_real = np.reshape(x_hat[:, :, :, 0], (len(x_hat), -1))
    x_hat_imag = np.reshape(x_hat[:, :, :, 1], (len(x_hat), -1))
    x_C = x_real  + 1j * (x_imag )
    x_hat_C = x_hat_real  + 1j * (x_hat_imag )
    power = np.sum(abs(x_C) ** 2, axis=1)
    mse = np.sum(abs(x_C - x_hat_C) ** 2, axis=1)
    nmse = np.mean(mse / power)
    return nmse