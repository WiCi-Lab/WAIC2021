import h5py
import numpy as np

import torch
import torch.nn as NN
from torch.utils.data import Dataset, DataLoader
from modelDesign import AIModel,NMSE
import math
#from torch.autograd import Variable
from torch.optim import lr_scheduler
#from torch.cuda.amp import autocast,GradScaler
from torch.nn import init
import torchvision.transforms as transforms

def mixup(im1, im2, prob=1.0, alpha=1.2):
    if alpha <= 0 or np.random.rand(1) >= prob:
        return im1, im2

    v = np.random.beta(alpha, alpha)
    r_index = torch.randperm(im1.size(0)).to(im2.device)

    im1 = v * im1 + (1-v) * im1[r_index, :]
    im2 = v * im2 + (1-v) * im2[r_index, :]
    
    return im1, im2

def rgb(im1, im2, prob=1.0):
    if np.random.rand(1) >= prob:
        return im1, im2

    perm = np.random.permutation(2)
    # i1 = im1
    # i2 = im2
    # im1[:, :,:,1] = i1[:, :,:,2]
    # im1[:, :,:,2] = i1[:, :,:,1]
    # im2[:, :,:,1] = i2[:, :,:,2]
    # im2[:, :,:,2] = i2[:, :,:,1]
    im1 = im1[:,:,: ,perm]
    im2 = im2[:, :,:,perm]
    # im1 = im1[:, perm]
    # im2 = im2[:, perm]

    return im1, im2


def flip1(im1, im2, prob1 = 1, prob=1.0):
    if np.random.rand(1) >= prob:
        return im1, im2
    
    if np.random.rand(1) >= prob1:
        im1 = torch.flip(im1,[1])
        im2 = torch.flip(im2,[1])
    else:
        im1 = torch.flip(im1,[2])
        im2 = torch.flip(im2,[2])

    return im1, im2

def _cutmix(im2, prob=1.0, alpha=1.0):
    if alpha <= 0 or np.random.rand(1) >= prob:
        return None

    cut_ratio = np.random.randn() * 0.01 + alpha

    h, w = im2.size(2), im2.size(3)
    ch, cw = int(h*cut_ratio), int(w*cut_ratio)

    fcy = np.random.randint(0, h-ch+1)
    fcx = np.random.randint(0, w-cw+1)
    tcy, tcx = fcy, fcx
    rindex = torch.randperm(im2.size(0)).to(im2.device)

    return {
        "rindex": rindex, "ch": ch, "cw": cw,
        "tcy": tcy, "tcx": tcx, "fcy": fcy, "fcx": fcx,
    }

def cutmix(im1, im2, prob=1.0, alpha=1.0):
    c = _cutmix(im2, prob, alpha)
    if c is None:
        return im1, im2

    scale = im1.size(2) // im2.size(2)
    rindex, ch, cw = c["rindex"], c["ch"], c["cw"]
    tcy, tcx, fcy, fcx = c["tcy"], c["tcx"], c["fcy"], c["fcx"]

    hch, hcw = ch*scale, cw*scale
    hfcy, hfcx, htcy, htcx = fcy*scale, fcx*scale, tcy*scale, tcx*scale

    im2[..., tcy:tcy+ch, tcx:tcx+cw] = im2[rindex, :, fcy:fcy+ch, fcx:fcx+cw]
    im1[..., htcy:htcy+hch, htcx:htcx+hcw] = im1[rindex, :, hfcy:hfcy+hch, hfcx:hfcx+hcw]

    return im1, im2


def cutmixup(
    im1, im2,    
    mixup_prob=1.0, mixup_alpha=1.0,
    cutmix_prob=1.0, cutmix_alpha=1.0
):
    c = _cutmix(im2, cutmix_prob, cutmix_alpha)
    if c is None:
        return im1, im2

    scale = im1.size(2) // im2.size(2)
    rindex, ch, cw = c["rindex"], c["ch"], c["cw"]
    tcy, tcx, fcy, fcx = c["tcy"], c["tcx"], c["fcy"], c["fcx"]

    hch, hcw = ch*scale, cw*scale
    hfcy, hfcx, htcy, htcx = fcy*scale, fcx*scale, tcy*scale, tcx*scale

    v = np.random.beta(mixup_alpha, mixup_alpha)
    if mixup_alpha <= 0 or np.random.rand(1) >= mixup_prob:
        im2_aug = im2[rindex, :]
        im1_aug = im1[rindex, :]

    else:
        im2_aug = v * im2 + (1-v) * im2[rindex, :]
        im1_aug = v * im1 + (1-v) * im1[rindex, :]

    # apply mixup to inside or outside
    if np.random.random() > 0.5:
        im2[..., tcy:tcy+ch, tcx:tcx+cw] = im2_aug[..., fcy:fcy+ch, fcx:fcx+cw]
        im1[..., htcy:htcy+hch, htcx:htcx+hcw] = im1_aug[..., hfcy:hfcy+hch, hfcx:hfcx+hcw]
    else:
        im2_aug[..., tcy:tcy+ch, tcx:tcx+cw] = im2[..., fcy:fcy+ch, fcx:fcx+cw]
        im1_aug[..., htcy:htcy+hch, htcx:htcx+hcw] = im1[..., hfcy:hfcy+hch, hfcx:hfcx+hcw]
        im2, im1 = im2_aug, im1_aug

    return im1, im2

class MyDataset(Dataset):
    def __init__(self, mat_file):
        mat = h5py.File(mat_file, 'r')
        
        X = np.transpose(mat['H_in'][:]).astype(np.float32)
        Y = np.transpose(mat['H_out'][:]).astype(np.float32)
        SNR = np.transpose(mat['SNR'][:]).astype(np.float32)
        # X = X.transpose([0,3,1,2])
        # Y = Y.transpose([0,3,1,2])
        # SNR = SNR.transpose([0,3,1,2])
        
        self.X = X
        self.Y = Y
        self.SNR = SNR

        del mat
        self.len = len(self.X)

    def __len__(self):
        # return len(self.X)
        return self.len

    def __getitem__(self, idx):
        x = self.X[idx]
        snr = self.SNR[idx]
        y = self.Y[idx]

        return (x, snr, y)
    
class mDataset(Dataset):
    def __init__(self, x,y,snr):
        self.X = x
        self.Y = y
        self.SNR = snr
        self.len = len(self.X)

    def __len__(self):
        # return len(self.X)
        return self.len

    def __getitem__(self, idx):
        x = self.X[idx]
        snr = self.SNR[idx]
        y = self.Y[idx]
        
        # if idx > 0 and idx%5 == 0:

        #     # Choose another image/label randomly
        #     mixup_idx = random.randint(0, len(x)-1)
        #     mixup_label = torch.zeros(10)
        #     label[self.targets[mixup_idx]] = 1.
        #         mixup_image = transform(self.data[mixup_idx])

        #     # Select a random number from the given beta distribution
        #     # Mixup the images accordingly
        #     alpha = 0.2
        #     lam = np.random.beta(alpha, alpha)
        #     image = lam * image + (1 - lam) * mixup_image
        #     label = lam * label + (1 - lam) * mixup_label

        # return image, label
        
        return (x, snr, y)
    
# def init_weights(net, init_type='normal', init_gain=0.02):
#     """Initialize network weights.

#     Parameters:
#         net (network)   -- network to be initialized
#         init_type (str) -- the name of an initialization method: normal | xavier | kaiming | orthogonal
#         init_gain (float)    -- scaling factor for normal, xavier and orthogonal.

#     We use 'normal' in the original pix2pix and CycleGAN paper. But xavier and kaiming might
#     work better for some applications. Feel free to try yourself.
#     """
#     def init_func(m):  # define the initialization function
#         classname = m.__class__.__name__
#         if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
#             if init_type == 'normal':
#                 init.normal_(m.weight.data, 0.0, init_gain)
#             elif init_type == 'xavier':
#                 init.xavier_normal_(m.weight.data, gain=init_gain)
#             elif init_type == 'kaiming':
#                 init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
#             elif init_type == 'orthogonal':
#                 init.orthogonal_(m.weight.data, gain=init_gain)
#             else:
#                 raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
#             if hasattr(m, 'bias') and m.bias is not None:
#                 init.constant_(m.bias.data, 0.0)
#         elif classname.find('BatchNorm2d') != -1:  # BatchNorm Layer's weight is not a matrix; only normal distribution applies.
#             init.normal_(m.weight.data, 1.0, init_gain)
#             init.constant_(m.bias.data, 0.0)

#     print('initialize network with %s' % init_type)
#     net.apply(init_func)  # apply the initialization function <init_func>


# def init_net(net, init_type='normal', init_gain=0.02, gpu_ids='cuda:0'):
#     """Initialize a network: 1. register CPU/GPU device (with multi-GPU support); 2. initialize the network weights
#     Parameters:
#         net (network)      -- the network to be initialized
#         init_type (str)    -- the name of an initialization method: normal | xavier | kaiming | orthogonal
#         gain (float)       -- scaling factor for normal, xavier and orthogonal.
#         gpu_ids (int list) -- which GPUs the network runs on: e.g., 0,1,2

#     Return an initialized network.
#     """
#     # if len(gpu_ids) > 0:
#     #     assert(torch.cuda.is_available())
#     #     net.to(gpu_ids[0])
#     #     net = torch.nn.DataParallel(net, gpu_ids)  # multi-GPUs
#     net.to(gpu_ids)
#     init_weights(net, init_type, init_gain=init_gain)
#     return net 


BATCH_SIZE = 128
LEARNING_RATE = 0.0005
TOTAL_EPOCHS = 300
model_save = '../user_data/modelSubmit.pth'
# model_save1 = 'modelSubmit1.pth'

# DEVICE = torch.device("cpu")
if torch.cuda.is_available():  
    DEVICE = torch.device("cuda:0")
    torch.backends.cudnn.benchmark = True

model = AIModel()
#init_net(model, init_type='normal', init_gain=0.02, gpu_ids='cuda:0')

# model_address = 'modelSubmit.pth'
#model_address = 'D:/大赛/oppo/pytorch_template/checkpoint/model_epoch_69.pth'
# model = torch.load(model_address).to(DEVICE)     

# torch.save(model.cpu(), model_save1)
cnn=model.to(DEVICE)
print(model)

def adjust_learning_rate(optimizer, epoch):
    """For resnet, the lr starts from 0.1, and is divided by 10 at 80 and 120 epochs"""
    learning_rate_init = 6e-4
    learning_rate_final = 8e-7
    epochs = TOTAL_EPOCHS
    lr = learning_rate_final + 0.5*(learning_rate_init-learning_rate_final)*(1+math.cos((epoch*3.14)/epochs))
    # lr = 0.00003* (1+math.cos(float(epoch)/TOTAL_EPOCHS*math.pi))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    return lr

def set_learning_rate(optimizer, lr):
    """For resnet, the lr starts from 0.1, and is divided by 10 at 80 and 120 epochs"""
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    return lr
        
def CharbonnierLoss(predict, target):
    return torch.mean(torch.sqrt(torch.pow((predict.cpu().double()-target.cpu().double()), 2) + 1e-6)) # epsilon=1e-3

def NMSEloss(predict, target):
    diff = torch.mean(torch.sum(torch.pow(torch.abs(predict.cpu()- target.cpu()),2)))
    abd = torch.mean(torch.sum(torch.pow(torch.abs(target.cpu()),2)))
#    ndiff = torch.div(diff,abd)
    ndiff = diff/abd
    return ndiff

#def NMSEt(x, x_hat):
#    x_real = torch.reshape(x[:, :, :, 0], (len(x), -1))
#    x_imag = torch.reshape(x[:, :, :, 1], (len(x), -1))
#    x_hat_real = torch.reshape(x_hat[:, :, :, 0], (len(x_hat), -1))
#    x_hat_imag = torch.reshape(x_hat[:, :, :, 1], (len(x_hat), -1))
#    x_C = x_real  + 1j * (x_imag )
#    x_hat_C = x_hat_real  + 1j * (x_hat_imag )
#    power = torch.sum(abs(x_C) ** 2, axis=1)
#    mse = torch.sum(abs(x_C - x_hat_C) ** 2, axis=1)
#    nmse = torch.mean(mse / power)
#    return nmse

if __name__ == '__main__':
    file_name_train = '../raw_data/Training_Data.mat'
    # file_name_val = 'Val_Data.mat' 

    
#    mat = h5py.File(file_name, 'r')
#
#    TotalNum = mat['N'][:]
#    X = np.transpose(mat['H_in'][:])
#    Y = np.transpose(mat['H_out'][:])
#    SNR = np.transpose(mat['SNR'][:])
#    
#    np.random.seed(2019)
#    n_examples = X.shape[0]
#    ran1 = np.random.permutation(n_examples)
#    xr = X[ran1]
#    yr = Y[ran1]
#    SNRr = SNR[ran1]
#    
#    sd=int(n_examples * 0.8)
#    
#    X_train = xr[:sd]
#    X_test = xr[sd:,]
#    y_train = yr[:sd]
#    y_test = yr[sd:]
#    
#    train_SNRs = SNRr[:sd]
#    test_SNRs = SNRr[sd:]

#    train_dataset = mDataset(X_train,y_train,train_SNRs)
      
#    train_transformer = transforms.Compose([
#    transforms.ToPILImage(),
#    # transforms.RandomResizedCrop(224,scale=(0.5,1.0)),
#    transforms.RandomHorizontalFlip( ),
#    transforms.ToTensor(),
#    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
#])
    
    train_dataset = MyDataset(mat_file = file_name_train)
    print('The current dataset is : %s' % (file_name_train))
    train_loader = DataLoader(dataset=train_dataset,
                                batch_size=BATCH_SIZE,
                                shuffle=True, num_workers=4, pin_memory=True)  # shuffle 标识要打乱顺序
    
    
    
#    test_dataset = mDataset(X_test,y_test,test_SNRs)
    # test_dataset = MyDataset(mat_file = file_name_val)
    # print('The current dataset is : %s' % (file_name_val))
    # test_loader = DataLoader(dataset=test_dataset,
    #                             batch_size=BATCH_SIZE,
    #                             shuffle=True, num_workers=4, pin_memory=True)  # shuffle 标识要打乱顺序
    
    criterion = NN.L1Loss().to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-6)
    
    # model.eval()
    # testnmse=[]
    # nmse=[]
    # for i, (x, snr, y) in enumerate(train_loader):
    #     x = x.float().to(DEVICE)
    #     y = y.to(DEVICE)
    #     snr = snr.to(DEVICE)
    #     # 清零
        
    #     outputs = model(x,snr)
    #     # 计算损失函数
    #     loss = criterion(outputs, y)
    #     # loss = NMSEt(outputs, y).to(DEVICE)
    #     testNMSE = NMSE(outputs.cpu().data.numpy(),y.cpu().data.numpy())
    #     testnmse.append(- 10 * np.log(testNMSE)/np.log(10))
    # mean_nmse= np.mean(testnmse)   
    # nmse.append(mean_nmse)
    
    # optimizer = torch.optim.SGD(model.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=1e-5,nesterov=True)
#    scheduler = lr_scheduler.ExponentialLR(optimizer, gamma=0.8)
#    scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=80, eta_min=0)
#    scaler = GradScaler()

    nmse=[]
    for epoch in range(TOTAL_EPOCHS):
#        print(epoch)
        testnmse=[]
#        lr=LEARNING_RATE
        model.train()
        # lr = LEARNING_RATE
        # if epoch <=80:
        #     lr1 = 0.0005
        # elif epoch>80 & epoch<=160:
        #     lr1 = 0.00025
        # elif epoch >160 & epoch <=240:
        #     lr1 = 0.0001
        # else:
        #     lr1 = 0.00005 
        # lr = set_learning_rate(optimizer, lr1)
        lr = adjust_learning_rate(optimizer, epoch)
#        if epoch <=100:
#            lr=LEARNING_RATE
#        else:
#            lr = adjust_learning_rate(optimizer, epoch-100)
        for i, (x, snr, y) in enumerate(train_loader):
            # x = x.permute(0, 3, 1, 2)
            # y = y.permute(0, 3, 1, 2)
#            
#            a,b,c,d=y.size() 
#            HR_4_target = np.zeros([a, int(b/2),int(c/2),d])
#    #            HR_8_target = np.zeros([a, int(b/8),c,d], dtype=np.float64)
#                
#            for i in range(1,c,2):
#                for j in range(1,b,2):
#                    HR_4_target[:,int(math.ceil(j/2)-1),int(math.ceil(i/2)-1),:]=y[:,j,i,:]
#            
#            x = x.float().to(DEVICE)
#            y = y.to(DEVICE)
#            HR_4_target = Variable(torch.from_numpy(HR_4_target)).cuda()
#
#            # 清零
#            optimizer.zero_grad()
#            outputs1, outputs2 = model(x,snr)
#            # 计算损失函数
#            loss1 = criterion(outputs1, HR_4_target.float())
#            loss2 = criterion(outputs2, y)   
#            loss = loss1 + loss2
            # x,y = mixup(x, y, prob=0.1, alpha=0.4)
            # x,y = cutmixup(x, y, mixup_prob=0.4, mixup_alpha=1.2, cutmix_prob=0.4, cutmix_alpha=0.7)
            # x,y= rgb(x, y, prob=0.1)
            # if np.random.random() > 0.5:
            #     x,y = cutmixup(x, y,     
            # mixup_prob=0.4, mixup_alpha=1.2,
            # cutmix_prob=0.4, cutmix_alpha=0.7)
            # else:
            #     x,y= rgb(x, y, prob=0.4)
            
            x = x.float().to(DEVICE)
            y = y.to(DEVICE)
            snr = snr.to(DEVICE)
              
   #          alpha=0.5
   #          lam = np.random.beta(alpha,alpha)
   # #randperm返回1~images.size(0)的一个随机排列
   #          index = torch.randperm(x.size(0)).cuda()
   #          inputs = lam*x + (1-lam)*x[index,:]
   #          targets_a, targets_b = y, y[index]
            
            optimizer.zero_grad()
#            with autocast():
            outputs=model(x,snr)
            # outputs = model(inputs,snr)
            # loss = lam * criterion(outputs, targets_a) + (1 - lam) * criterion(outputs, targets_b)
            loss = criterion(outputs, y)
#            loss = NMSEt(outputs, y).to(DEVICE)
#            scaler.scale(loss).backward()
#            scaler.step(optimizer)
#            scaler.update()
            loss.backward()  
            optimizer.step()
#            scheduler.step()
            if (i+1)%200==0:
                trainNMSE = NMSE(outputs.cpu().data.numpy(),y.cpu().data.numpy())
                print('Epoch : %d/%d, Iter : %d/%d,  leraningRate : %.6f, trainLoss: %.6f, trainNMSE: %.6f' % (
                epoch + 1, TOTAL_EPOCHS, i + 1, len(train_dataset) // BATCH_SIZE, lr,loss.data.item(),-10*np.log(trainNMSE)/np.log(10)))
            
        # with torch.no_grad():
        #     model.eval()
        #     for i, (x, snr, y) in enumerate(test_loader):
        #         # x = x.permute(0, 3, 1, 2)
        #         # y = y.permute(0, 3, 1, 2)
        #         x = x.float().to(DEVICE)
        #         y = y.to(DEVICE)
        #         snr = snr.to(DEVICE)
        #         # 清零
                
        #         outputs = model(x,snr)
        #         # 计算损失函数
        #         loss = criterion(outputs, y)
        #         # loss = NMSEt(outputs, y).to(DEVICE)
        #         testNMSE = NMSE(outputs.cpu().data.numpy(),y.cpu().data.numpy())
        #         if i%100==0:
        #             print('Epoch : %d/%d, Iter : %d/%d,  testLoss: %.6f,  testNMSE: %.6f' % (
        #             epoch + 1, TOTAL_EPOCHS, i + 1, len(test_dataset) // BATCH_SIZE, loss.data.item(), -10*np.log(testNMSE)/np.log(10)))
        #         testnmse.append(- 10 * np.log(testNMSE)/np.log(10))
        #     mean_nmse= np.mean(testnmse)   
        #     nmse.append(mean_nmse)
        #     print('Epoch : %d/%d,  testNMSE: %.6f' % (
        #             epoch + 1, TOTAL_EPOCHS,  mean_nmse))
        # if (epoch+1)%10==0:
        #     model_out_path = "checkpoint/model_epoch_aug{}.pth".format(epoch)
        #     torch.save(model, model_out_path)
    
    torch.save(model.cpu(), model_save)
    # torch.save(model.state_dict(), model_save)
#    snrs = np.linspace(0,20,21)
#    i1=0;
#    for snr in snrs:
#        print('SNR: %f' % (snr))
##    count = count+1
#    # extract classes @ SNR
#        test_X_i = X_test[np.where(np.array(test_SNRs)==snr)]
#        test_Y_i = y_test[np.where(np.array(test_SNRs)==snr)]
#        
#        X_test1=torch.Tensor(test_X_i)
#        
#        test_set1 = torch.utils.data.TensorDataset(X_test1)
#        
#        data_test_loader1 = torch.utils.data.DataLoader(test_set1, batch_size= 100, shuffle=True)
#    
#        # estimate classes
#        acc2[0,int(i1)] = model(test_X_i,snr)
#        i1=i1+1

else:
    print("load torch model")
    # model_ckpt = torch.load(model, model_save)
