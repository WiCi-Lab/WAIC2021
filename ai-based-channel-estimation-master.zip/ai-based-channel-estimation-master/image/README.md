1.镜像文件百度网盘链接: https://pan.baidu.com/s/1zZSA3HjEDtm16ZSuOCCcIQ 密码: pqu5

1）镜像文件相关包的版本说明  
pytorch   1.8.1-cuda10.2-cudnn7-runtime  
nvidia/cuda       10.2-base  
2）镜像文件生成说明  
a.通过sudo docker pull 命令安装pytorch  
b.通过dockfile文件编译生成镜像，其中在dockfile中额外安装了h5py库  
c.镜像文件不包含数据集文件  

2.程序运行
安装镜像 sudo docker load < victor.tar  
运行指令 sudo nvidia-docker run -v /data:/data victor sh run.sh

说明：  
1）宿主机挂载需要填写data文件夹的绝对路径。  
2）宿主机挂载路径不要在根目录下，因为运行代码时在根目录下会没有权限生成结果文件和模型文件。  
3）训练好的模型保存在user_data目录下，预测结果result.txt生成在predict_code文件夹。  
4）run.sh文件已写入镜像，通过运行本地代码时可将run.sh移至代码目录路径下即，因此在./data 目录下我们也上传了一个同样的run.sh文件。  
5）由于镜像中已包含所有程序，所以程序既可以通过进入镜像中执行，也可以在本地执行。若在镜像中执行，则生成的结果文件和模型文件在镜像相应目录下。由于镜像中的数据集被移出，若在镜像执行时，还需要把数据集上传到镜像中。

3.本地测试已通过，示例结果如下：  
（示例说明：训练代码只取一个epoch并打印model信息，训练集为官方训练集，测试数据从训练数据随机选取部分数据得到，数据读取路径和模型文件和result.txt生成路径均为官方文档所要求目录，测试镜像名为test1并内含数据集，而实际提交的镜像名为victor且不包含数据集；'/media/ubuntu/988b23a2-5ac2-41ca-8c12-fbea99e6935f/HX/data'为我队本地测试时data文件夹存放路径）

(base) ubuntu@ubuntu:/media/ubuntu/988b23a2-5ac2-41ca-8c12-fbea99e6935f/HX/data$ sudo nvidia-docker run -v /media/ubuntu/988b23a2-5ac2-41ca-8c12-fbea99e6935f/HX/data:/data test1 sh run.sh

AIModel(
  (resconvbb): _Res_Blockb(
    (res_conv): Conv2d(32, 192, kernel_size=(1, 1), stride=(1, 1))
    (res_conb): Conv2d(192, 25, kernel_size=(1, 1), stride=(1, 1))
    (res_conl): Conv2d(25, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
  )
  (resconv): _Res_Block(
    (res_conv): Conv2d(192, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(192, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(192, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (resconvb): _Res_Block(
    (res_conv): Conv2d(48, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(48, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(48, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (Maxpool1): MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1, ceil_mode=False)
  (Maxpool2): MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1, ceil_mode=False)
  (ConvII): conv_block1(
    (conv): Sequential(
      (0): Conv2d(50, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (1): PReLU(num_parameters=1)
    )
  )
  (Conv1): _Res_Block(
    (res_conv): Conv2d(48, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(48, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(48, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (Conv2): _Res_Block(
    (res_conv): Conv2d(96, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(96, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(96, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (Conv3): _Res_Block(
    (res_conv): Conv2d(192, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(192, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(192, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (Conv11): conv_block1(
    (conv): Sequential(
      (0): Conv2d(2, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (1): PReLU(num_parameters=1)
    )
  )
  (Conv22): conv_block1(
    (conv): Sequential(
      (0): Conv2d(48, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (1): PReLU(num_parameters=1)
    )
  )
  (Conv33): conv_block1(
    (conv): Sequential(
      (0): Conv2d(96, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (1): PReLU(num_parameters=1)
    )
  )
  (Up3): up_conv(
    (up): Sequential(
      (0): Upsample(scale_factor=2.0, mode=nearest)
      (1): Conv2d(192, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (2): PReLU(num_parameters=1)
    )
  )
  (Up33): conv_block1(
    (conv): Sequential(
      (0): Conv2d(192, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (1): PReLU(num_parameters=1)
    )
  )
  (Up_conv3): _Res_Block(
    (res_conv): Conv2d(96, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(96, 96, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(96, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (Up2): up_conv(
    (up): Sequential(
      (0): Upsample(scale_factor=2.0, mode=nearest)
      (1): Conv2d(96, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (2): PReLU(num_parameters=1)
    )
  )
  (Up_conv2): _Res_Block(
    (res_conv): Conv2d(48, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (res_conb): Conv2d(48, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
    (relu): PReLU(num_parameters=1)
    (instan): InstanceNorm2d(48, eps=1e-05, momentum=0.1, affine=False, track_running_stats=False)
  )
  (Up22): conv_block1(
    (conv): Sequential(
      (0): Conv2d(96, 48, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
      (1): PReLU(num_parameters=1)
    )
  )
  (Conv): Conv2d(48, 2, kernel_size=(1, 1), stride=(1, 1))
  (active): Tanh()
)

The current dataset is : ../raw_data/Training_Data.mat

Epoch : 1/1, Iter : 200/1640,  leraningRate : 0.000600, trainLoss: 0.066125, trainNMSE: 21.079190  
Epoch : 1/1, Iter : 400/1640,  leraningRate : 0.000600, trainLoss: 0.051954, trainNMSE: 21.398103  
Epoch : 1/1, Iter : 600/1640,  leraningRate : 0.000600, trainLoss: 0.046042, trainNMSE: 22.414057  
Epoch : 1/1, Iter : 800/1640,  leraningRate : 0.000600, trainLoss: 0.046607, trainNMSE: 22.252307  
Epoch : 1/1, Iter : 1000/1640,  leraningRate : 0.000600, trainLoss: 0.047939, trainNMSE: 20.163453  
Epoch : 1/1, Iter : 1200/1640,  leraningRate : 0.000600, trainLoss: 0.042574, trainNMSE: 24.450076  
Epoch : 1/1, Iter : 1400/1640,  leraningRate : 0.000600, trainLoss: 0.044187, trainNMSE: 22.654633  
Epoch : 1/1, Iter : 1600/1640,  leraningRate : 0.000600, trainLoss: 0.044617, trainNMSE: 21.806719  

The current dataset is : ../raw_data/Test_Data.mat

The score of 0dB is 15.279063495643674  
The score of 5dB is 19.899187445238187  
The score of 10dB is 26.671628960979636  
The score of 15dB is 28.529709199573922  
The score of 20dB is 30.206967579888214  
The final score is 24.117311336264727  
END  
