# AI-based channel estimation

队伍ID: 207464

队伍名称：victor
